//package lambda;
//
//abstract class iA{
//    public abstract void fn();
//    public void fn3(){
//        System.out.println("Hello from abstract class");
//    }
//}
//
//public class Exp4 {
//    
//    static void fnn(iA a){
//        a.fn();
//        a.fn3();
//    }
//    
//    public static void main(String[] args) {
//        
//        iA a=new iA(){
//            public void fn(){
//                System.out.println("Hello from A");
//            }
//        };
//        fnn(a);
//    
//        iA b=new iA(){
//            public void fn(){
//                System.out.println("Hello from B");
//            }
//        };
//        fnn(b);
//        
//    }
//    
//}