//package lambda;
//
//interface iA{
//    void fn();
//}
//
//public class Exp {
//    static class A implements iA{
//        public void fn(){
//            System.out.println("Hello from A");
//        }
//    }
//    static class B implements iA{
//        public void fn(){
//            System.out.println("Hello from B");
//        }
//    }
//    static void fnn(iA a){
//        a.fn();
//    }
//    
//    public static void main(String[] args) {
//        iA a=new A();
//        fnn(a);
//        iA b=new B();
//        fnn(b);
//        
//}
//    
//}