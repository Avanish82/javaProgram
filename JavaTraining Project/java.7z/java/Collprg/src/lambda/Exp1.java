//package lambda;
//
//interface A{
//    void fn();
//}
//
// 
//
//public class Exp1 {
////    static class A implements iA{
////        public void fn(){
////            System.out.println("Hello from A");
////        }
////    }
////    static class B implements iA{
////        public void fn(){
////            System.out.println("Hello from B");
////        }
////    }
//    static void fnn(A a){
//        a.fn();
//    }
//    
//    public static void main(String[] args) {
//        A a=new A(){
//            public void fn(){
//                System.out.println("Hello from A");
//            }
//        };
//        fnn(a);
//        A b=new A(){
//            public void fn(){
//                System.out.println("Hello from B");
//            }
//        };
//        fnn(b);
//        
//}
//    
//}
