
import java.io.InputStream;
import java.util.Scanner;


public class Exp9 {
public static void main(String[] args) {

 System.out.println("Enter Any Number: ");
Scanner sc = new Scanner(System.in);
int num = sc.nextInt();
int num1 = 0;
try{

 num1 = 100/num;

}
catch(Exception e){

 System.out.println("Plese enter valid number: " + num1);

 }
}
}
//}import java.io.InputStream;
//import java.util.Scanner;
//
//
//public class Exp9 {
//public static void main(String[] args) {
//
// System.out.println("Enter Any Number: ");
//Scanner sc = new Scanner(System.in);
//int num = sc.nextInt();
//int num1 = 0;
//try{
//
// num1 = 100/num;
//
//}
//catch(Exception e){
//
// System.out.println("Plese enter valid number: " + num1);
//
// }
//}
//}